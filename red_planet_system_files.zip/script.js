const WEBHOOK_URL = "PASTE_YOUR_N8N_OR_FORM_ENDPOINT_HERE";

const form = document.getElementById("joinForm");
const statusEl = document.getElementById("formStatus");

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  const formData = new FormData(form);
  const payload = Object.fromEntries(formData.entries());

  statusEl.textContent = "Submitting application...";

  if (WEBHOOK_URL === "PASTE_YOUR_N8N_OR_FORM_ENDPOINT_HERE") {
    statusEl.textContent = "Add your webhook URL in script.js to make the form live.";
    console.log("Form payload:", payload);
    return;
  }

  try {
    const response = await fetch(WEBHOOK_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        source: "Red Planet Landing Page",
        submittedAt: new Date().toISOString(),
        ...payload
      })
    });

    if (!response.ok) {
      throw new Error("Failed to submit form");
    }

    form.reset();
    statusEl.textContent = "Application submitted. The system has received this person.";
  } catch (error) {
    console.error(error);
    statusEl.textContent = "Something failed. Check your webhook or automation setup.";
  }
});
