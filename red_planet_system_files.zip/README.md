# Red Planet System Files

This package gives you a working front-end system starter for Red Planet.

## Files
- `index.html` — landing page + recruitment funnel UI
- `style.css` — full styling
- `script.js` — form submit logic
- `n8n-workflow.json` — starter automation workflow structure

## How to use
1. Open `index.html` in a browser.
2. Edit `script.js` and replace the placeholder webhook URL.
3. Point that webhook to n8n, Make, Zapier, Formspree, Supabase Edge Function, or your backend.
4. In your automation:
   - receive applicant data
   - store it in Google Sheets / Airtable / database
   - send welcome message
   - assign first task
   - notify admin

## Suggested backend flow
Form Submit → Webhook → Google Sheet/Airtable → Message template → Task assignment → Admin alert

## Suggested stack
- Front-end: HTML/CSS/JS
- Database: Airtable / Google Sheets / Supabase
- Automation: n8n
- Messaging: WhatsApp API, Telegram bot, email, or SMS
