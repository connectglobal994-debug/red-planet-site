RED PLANET PLAIN SITE

Files:
- index.html
- style.css
- script.js

How to use:
1. Open index.html in a browser.
2. The form currently works as a front-end demo only.
3. Submitted data is logged to the browser console.

To make it live:
- Connect the form to Google Forms, Formspree, Airtable, Supabase, or an n8n webhook.
- Add your real links in the navigation or CTA buttons.
- Replace the placeholder messaging with your real onboarding flow.
