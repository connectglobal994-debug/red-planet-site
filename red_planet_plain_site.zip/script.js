const form = document.getElementById('joinForm');
const message = document.getElementById('formMessage');

if (form) {
  form.addEventListener('submit', function (event) {
    event.preventDefault();

    const formData = new FormData(form);
    const payload = {
      name: formData.get('name'),
      country: formData.get('country'),
      skill: formData.get('skill'),
      whatsapp: formData.get('whatsapp')
    };

    console.log('Red Planet applicant:', payload);

    message.classList.remove('hidden');
    message.innerHTML = `
      <strong>Demo captured.</strong><br>
      This plain HTML version logs the applicant in the browser console.<br>
      Next step: connect this form to Google Sheets, Airtable, Formspree, or an n8n webhook.
    `;

    form.reset();
  });
}
